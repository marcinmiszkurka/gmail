/* dolacz biblioteke stanbdardowa input-output*/
#include <stdio.h>

/* y=f(x) */ /* tam co funkcja w takich nawiasach okresla sie opisy*/
/*  main()=> 0 */

int dodaj(int a, int b) /* funkcja glowna programu, zwraaca wartosc całkowita*/
{
return a+b;
}

int main()
{printf("%di/n , dodaj(4,5));

	return 0; /*main zwraca wartosc 0*/

}
