/* dolacz biblioteke stanbdardowa input-output*/
#include <stdio.h>

/* y=f(x) */ /* tam co funkcja w takich nawiasach okresla sie opisy*/
/*  main()=> 0 */

int main() /* funkcja glowna programu, zwraaca wartosc całkowita*/
{ /*miedzy klamrami jest ciało funkcji*/

	puts("Pierwszy program"); /*funkcja z biblioteki stdio*/
	return 0; /*main zwraca wartosc 0*/

}
